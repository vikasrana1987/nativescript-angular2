var makeConfig = require("./webpack.common");
module.exports = makeConfig("ios");
