"use strict";
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var forms_1 = require("nativescript-angular/forms");
var core_1 = require("@angular/core");
var items_routing_1 = require("./items.routing");
var items_component_1 = require("./items.component");
var item_detail_component_1 = require("./item-detail.component");
var items_firstcharacter_pipe_1 = require("./items-firstcharacter.pipe");
var ItemsModule = (function () {
    function ItemsModule() {
    }
    return ItemsModule;
}());
ItemsModule = __decorate([
    core_1.NgModule({
        imports: [
            nativescript_module_1.NativeScriptModule,
            forms_1.NativeScriptFormsModule,
            items_routing_1.itemsRouting
        ],
        declarations: [
            items_component_1.ItemsComponent,
            item_detail_component_1.ItemDetailComponent,
            items_firstcharacter_pipe_1.FirstcharacterPipe
        ],
        schemas: [core_1.NO_ERRORS_SCHEMA]
    })
], ItemsModule);
exports.ItemsModule = ItemsModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbXMubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaXRlbXMubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxnRkFBOEU7QUFDOUUsb0RBQXFFO0FBQ3JFLHNDQUEyRDtBQUMzRCxpREFBK0M7QUFDL0MscURBQW1EO0FBQ25ELGlFQUE4RDtBQUU5RCx5RUFBaUU7QUFlakUsSUFBYSxXQUFXO0lBQXhCO0lBQTBCLENBQUM7SUFBRCxrQkFBQztBQUFELENBQUMsQUFBM0IsSUFBMkI7QUFBZCxXQUFXO0lBYnZCLGVBQVEsQ0FBQztRQUNSLE9BQU8sRUFBRTtZQUNQLHdDQUFrQjtZQUNsQiwrQkFBdUI7WUFDdkIsNEJBQVk7U0FDYjtRQUNELFlBQVksRUFBRTtZQUNaLGdDQUFjO1lBQ2QsMkNBQW1CO1lBQ25CLDhDQUFrQjtTQUNuQjtRQUNELE9BQU8sRUFBRSxDQUFDLHVCQUFnQixDQUFDO0tBQzVCLENBQUM7R0FDVyxXQUFXLENBQUc7QUFBZCxrQ0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdGl2ZVNjcmlwdE1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9uYXRpdmVzY3JpcHQubW9kdWxlXCI7XG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRGb3Jtc01vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9mb3Jtc1wiO1xuaW1wb3J0IHsgTmdNb2R1bGUsIE5PX0VSUk9SU19TQ0hFTUEgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgaXRlbXNSb3V0aW5nIH0gZnJvbSBcIi4vaXRlbXMucm91dGluZ1wiO1xuaW1wb3J0IHsgSXRlbXNDb21wb25lbnQgfSBmcm9tIFwiLi9pdGVtcy5jb21wb25lbnRcIjtcbmltcG9ydCB7IEl0ZW1EZXRhaWxDb21wb25lbnQgfSBmcm9tIFwiLi9pdGVtLWRldGFpbC5jb21wb25lbnRcIjtcblxuaW1wb3J0IHsgRmlyc3RjaGFyYWN0ZXJQaXBlIH0gZnJvbSBcIi4vaXRlbXMtZmlyc3RjaGFyYWN0ZXIucGlwZVwiO1xuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgTmF0aXZlU2NyaXB0TW9kdWxlLFxuICAgIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLFxuICAgIGl0ZW1zUm91dGluZ1xuICBdLFxuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBJdGVtc0NvbXBvbmVudCxcbiAgICBJdGVtRGV0YWlsQ29tcG9uZW50LFxuICAgIEZpcnN0Y2hhcmFjdGVyUGlwZVxuICBdLFxuICBzY2hlbWFzOiBbTk9fRVJST1JTX1NDSEVNQV1cbn0pXG5leHBvcnQgY2xhc3MgSXRlbXNNb2R1bGUge31cbiJdfQ==