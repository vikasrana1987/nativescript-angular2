"use strict";
var core_1 = require("@angular/core");
var platform_1 = require("platform");
var application = require("application");
/**
 * Android Only.
 *
 * Directive which removes border from the button when applied on android.
 */
var BorderlessBtnDirective = (function () {
    function BorderlessBtnDirective(_el) {
        this._el = _el;
    }
    BorderlessBtnDirective.prototype.setBorderlessBackground = function () {
        var outValue = new android.util.TypedValue();
        application.android.context.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
        this.nsBtn.android.setBackgroundResource(outValue.resourceId);
    };
    BorderlessBtnDirective.prototype.ngOnInit = function () {
        var _this = this;
        if (platform_1.isAndroid) {
            this.nsBtn = this._el.nativeElement;
            // if the view has already loaded - set immediately
            if (this.nsBtn.isLoaded) {
                this.setBorderlessBackground();
            }
            // Attach the setter for future loaded events
            this.nsBtn.on("loaded", function () { _this.setBorderlessBackground(); });
        }
    };
    BorderlessBtnDirective.prototype.ngOnDestroy = function () {
        // Cleanup
        if (platform_1.isAndroid) {
            this.nsBtn.off("loaded");
            this.nsBtn = undefined;
        }
    };
    return BorderlessBtnDirective;
}());
BorderlessBtnDirective = __decorate([
    core_1.Directive({
        selector: ".borderless-btn"
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], BorderlessBtnDirective);
exports.BorderlessBtnDirective = BorderlessBtnDirective;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm9yZGVybGVzcy1idG4uZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYm9yZGVybGVzcy1idG4uZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzQ0FBeUU7QUFHekUscUNBQXFDO0FBQ3JDLHlDQUEyQztBQUkzQzs7OztHQUlHO0FBSUgsSUFBYSxzQkFBc0I7SUFJakMsZ0NBQW9CLEdBQWU7UUFBZixRQUFHLEdBQUgsR0FBRyxDQUFZO0lBQUksQ0FBQztJQUV4Qyx3REFBdUIsR0FBdkI7UUFDRSxJQUFJLFFBQVEsR0FBRyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDN0MsV0FBVyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsZ0JBQWdCLENBQ3JELE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLFFBQVEsRUFBRSxJQUFJLENBQ3hELENBQUM7UUFDRixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVELHlDQUFRLEdBQVI7UUFBQSxpQkFZQztRQVhDLEVBQUUsQ0FBQyxDQUFDLG9CQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ2QsSUFBSSxDQUFDLEtBQUssR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQztZQUU1QyxtREFBbUQ7WUFDbkQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUN4QixJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUNqQyxDQUFDO1lBRUQsNkNBQTZDO1lBQzdDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxjQUFRLEtBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckUsQ0FBQztJQUNILENBQUM7SUFFRCw0Q0FBVyxHQUFYO1FBQ0UsVUFBVTtRQUNWLEVBQUUsQ0FBQyxDQUFDLG9CQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ2QsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDekIsSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUM7UUFDekIsQ0FBQztJQUNILENBQUM7SUFDSCw2QkFBQztBQUFELENBQUMsQUFuQ0QsSUFtQ0M7QUFuQ1ksc0JBQXNCO0lBSGxDLGdCQUFTLENBQUM7UUFDVCxRQUFRLEVBQUUsaUJBQWlCO0tBQzVCLENBQUM7cUNBS3lCLGlCQUFVO0dBSnhCLHNCQUFzQixDQW1DbEM7QUFuQ1ksd0RBQXNCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBFbGVtZW50UmVmLCBPbkluaXQsIE9uRGVzdHJveSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5cbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJ1aS9idXR0b25cIjtcbmltcG9ydCB7IGlzQW5kcm9pZCB9IGZyb20gXCJwbGF0Zm9ybVwiO1xuaW1wb3J0ICogYXMgYXBwbGljYXRpb24gZnJvbSBcImFwcGxpY2F0aW9uXCI7XG5cbmRlY2xhcmUgY29uc3QgYW5kcm9pZDogYW55O1xuXG4vKipcbiAqIEFuZHJvaWQgT25seS5cbiAqXG4gKiBEaXJlY3RpdmUgd2hpY2ggcmVtb3ZlcyBib3JkZXIgZnJvbSB0aGUgYnV0dG9uIHdoZW4gYXBwbGllZCBvbiBhbmRyb2lkLlxuICovXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6IFwiLmJvcmRlcmxlc3MtYnRuXCJcbn0pXG5leHBvcnQgY2xhc3MgQm9yZGVybGVzc0J0bkRpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcblxuICBwcml2YXRlIG5zQnRuOiBCdXR0b247XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfZWw6IEVsZW1lbnRSZWYpIHsgfVxuXG4gIHNldEJvcmRlcmxlc3NCYWNrZ3JvdW5kKCkge1xuICAgIGxldCBvdXRWYWx1ZSA9IG5ldyBhbmRyb2lkLnV0aWwuVHlwZWRWYWx1ZSgpO1xuICAgIGFwcGxpY2F0aW9uLmFuZHJvaWQuY29udGV4dC5nZXRUaGVtZSgpLnJlc29sdmVBdHRyaWJ1dGUoXG4gICAgICBhbmRyb2lkLlIuYXR0ci5zZWxlY3RhYmxlSXRlbUJhY2tncm91bmQsIG91dFZhbHVlLCB0cnVlXG4gICAgKTtcbiAgICB0aGlzLm5zQnRuLmFuZHJvaWQuc2V0QmFja2dyb3VuZFJlc291cmNlKG91dFZhbHVlLnJlc291cmNlSWQpO1xuICB9XG5cbiAgbmdPbkluaXQoKSB7XG4gICAgaWYgKGlzQW5kcm9pZCkge1xuICAgICAgdGhpcy5uc0J0biA9IDxCdXR0b24+dGhpcy5fZWwubmF0aXZlRWxlbWVudDtcblxuICAgICAgLy8gaWYgdGhlIHZpZXcgaGFzIGFscmVhZHkgbG9hZGVkIC0gc2V0IGltbWVkaWF0ZWx5XG4gICAgICBpZiAodGhpcy5uc0J0bi5pc0xvYWRlZCkge1xuICAgICAgICB0aGlzLnNldEJvcmRlcmxlc3NCYWNrZ3JvdW5kKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIEF0dGFjaCB0aGUgc2V0dGVyIGZvciBmdXR1cmUgbG9hZGVkIGV2ZW50c1xuICAgICAgdGhpcy5uc0J0bi5vbihcImxvYWRlZFwiLCAoKSA9PiB7IHRoaXMuc2V0Qm9yZGVybGVzc0JhY2tncm91bmQoKTsgfSk7XG4gICAgfVxuICB9XG5cbiAgbmdPbkRlc3Ryb3koKSB7XG4gICAgLy8gQ2xlYW51cFxuICAgIGlmIChpc0FuZHJvaWQpIHtcbiAgICAgIHRoaXMubnNCdG4ub2ZmKFwibG9hZGVkXCIpO1xuICAgICAgdGhpcy5uc0J0biA9IHVuZGVmaW5lZDtcbiAgICB9XG4gIH1cbn1cbiJdfQ==