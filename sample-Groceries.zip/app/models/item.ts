export class Item {
    id: number;
    name: string;
    description: string;
    image: string;
    isFavorite: boolean;
}
