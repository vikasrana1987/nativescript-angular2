"use strict";
var Item = (function () {
    function Item() {
    }
    return Item;
}());
exports.Item = Item;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIml0ZW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0lBQUE7SUFNQSxDQUFDO0lBQUQsV0FBQztBQUFELENBQUMsQUFORCxJQU1DO0FBTlksb0JBQUkiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgSXRlbSB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgICBpbWFnZTogc3RyaW5nO1xuICAgIGlzRmF2b3JpdGU6IGJvb2xlYW47XG59XG4iXX0=