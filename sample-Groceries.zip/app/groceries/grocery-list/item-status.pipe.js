"use strict";
var core_1 = require("@angular/core");
var ItemStatusPipe = (function () {
    function ItemStatusPipe() {
        this.value = [];
    }
    ItemStatusPipe.prototype.transform = function (items, deleted) {
        if (items && items.length) {
            this.value = items.filter(function (grocery) {
                return grocery.deleted === deleted;
            });
        }
        return this.value;
    };
    return ItemStatusPipe;
}());
ItemStatusPipe = __decorate([
    core_1.Pipe({
        name: "itemStatus"
    })
], ItemStatusPipe);
exports.ItemStatusPipe = ItemStatusPipe;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS1zdGF0dXMucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIml0ZW0tc3RhdHVzLnBpcGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUFvRDtBQU9wRCxJQUFhLGNBQWM7SUFIM0I7UUFJRSxVQUFLLEdBQW1CLEVBQUUsQ0FBQztJQVM3QixDQUFDO0lBUkMsa0NBQVMsR0FBVCxVQUFVLEtBQXFCLEVBQUUsT0FBZ0I7UUFDL0MsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQzFCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFDLE9BQWdCO2dCQUN6QyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sS0FBSyxPQUFPLENBQUM7WUFDckMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDcEIsQ0FBQztJQUNILHFCQUFDO0FBQUQsQ0FBQyxBQVZELElBVUM7QUFWWSxjQUFjO0lBSDFCLFdBQUksQ0FBQztRQUNKLElBQUksRUFBRSxZQUFZO0tBQ25CLENBQUM7R0FDVyxjQUFjLENBVTFCO0FBVlksd0NBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcblxuaW1wb3J0IHsgR3JvY2VyeSB9IGZyb20gXCIuLi9zaGFyZWRcIjtcblxuQFBpcGUoe1xuICBuYW1lOiBcIml0ZW1TdGF0dXNcIlxufSlcbmV4cG9ydCBjbGFzcyBJdGVtU3RhdHVzUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xuICB2YWx1ZTogQXJyYXk8R3JvY2VyeT4gPSBbXTtcbiAgdHJhbnNmb3JtKGl0ZW1zOiBBcnJheTxHcm9jZXJ5PiwgZGVsZXRlZDogYm9vbGVhbikge1xuICAgIGlmIChpdGVtcyAmJiBpdGVtcy5sZW5ndGgpIHtcbiAgICAgIHRoaXMudmFsdWUgPSBpdGVtcy5maWx0ZXIoKGdyb2Nlcnk6IEdyb2NlcnkpID0+IHtcbiAgICAgICAgcmV0dXJuIGdyb2NlcnkuZGVsZXRlZCA9PT0gZGVsZXRlZDtcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy52YWx1ZTtcbiAgfVxufSJdfQ==