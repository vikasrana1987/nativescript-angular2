"use strict";
var core_1 = require("@angular/core");
var utils = require("utils/utils");
var shared_1 = require("../shared");
var shared_2 = require("../../shared");
var GroceryListComponent = (function () {
    function GroceryListComponent(store) {
        this.store = store;
        this.loading = new core_1.EventEmitter();
        this.loaded = new core_1.EventEmitter();
        this.listLoaded = false;
    }
    GroceryListComponent.prototype.load = function () {
        var _this = this;
        this.loading.next("");
        this.store.load()
            .subscribe(function () {
            _this.loaded.next("");
            _this.listLoaded = true;
        }, function () {
            shared_2.alert("An error occurred loading your grocery list.");
        });
    };
    // The following trick makes the background color of each cell
    // in the UITableView transparent as it’s created.
    GroceryListComponent.prototype.makeBackgroundTransparent = function (args) {
        var cell = args.ios;
        if (cell) {
            // support XCode 8
            cell.backgroundColor = utils.ios.getter(UIColor, UIColor.clearColor);
        }
    };
    GroceryListComponent.prototype.imageSource = function (grocery) {
        if (grocery.deleted) {
            return grocery.done ? "res://selected" : "res://nonselected";
        }
        return grocery.done ? "res://checked" : "res://unchecked";
    };
    GroceryListComponent.prototype.toggleDone = function (grocery) {
        if (grocery.deleted) {
            grocery.done = !grocery.done;
            return;
        }
        this.store.toggleDoneFlag(grocery)
            .subscribe(function () { }, function () {
            shared_2.alert("An error occurred managing your grocery list.");
        });
    };
    GroceryListComponent.prototype.delete = function (grocery) {
        var _this = this;
        this.loading.next("");
        var successHandler = function () { return _this.loaded.next(""); };
        var errorHandler = function () {
            shared_2.alert("An error occurred while deleting an item from your list.");
            _this.loaded.next("");
        };
        if (grocery.deleted) {
            this.store.permanentlyDelete(grocery)
                .subscribe(successHandler, errorHandler);
        }
        else {
            this.store.setDeleteFlag(grocery)
                .subscribe(successHandler, errorHandler);
        }
    };
    return GroceryListComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], GroceryListComponent.prototype, "showDeleted", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], GroceryListComponent.prototype, "row", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], GroceryListComponent.prototype, "loading", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], GroceryListComponent.prototype, "loaded", void 0);
GroceryListComponent = __decorate([
    core_1.Component({
        selector: "gr-grocery-list",
        moduleId: module.id,
        templateUrl: "./grocery-list.component.html",
        styleUrls: ["./grocery-list.component.css"],
        changeDetection: core_1.ChangeDetectionStrategy.OnPush
    }),
    __metadata("design:paramtypes", [shared_1.GroceryService])
], GroceryListComponent);
exports.GroceryListComponent = GroceryListComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JvY2VyeS1saXN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImdyb2NlcnktbGlzdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUFnRztBQUNoRyxtQ0FBcUM7QUFFckMsb0NBQW9EO0FBQ3BELHVDQUFxQztBQVdyQyxJQUFhLG9CQUFvQjtJQVEvQiw4QkFBb0IsS0FBcUI7UUFBckIsVUFBSyxHQUFMLEtBQUssQ0FBZ0I7UUFML0IsWUFBTyxHQUFHLElBQUksbUJBQVksRUFBRSxDQUFDO1FBQzdCLFdBQU0sR0FBRyxJQUFJLG1CQUFZLEVBQUUsQ0FBQztRQUV0QyxlQUFVLEdBQUcsS0FBSyxDQUFDO0lBRTBCLENBQUM7SUFFOUMsbUNBQUksR0FBSjtRQUFBLGlCQVlDO1FBWEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUU7YUFDZCxTQUFTLENBQ1I7WUFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyQixLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN6QixDQUFDLEVBQ0Q7WUFDRSxjQUFLLENBQUMsOENBQThDLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQ0YsQ0FBQztJQUNOLENBQUM7SUFFRCw4REFBOEQ7SUFDOUQsa0RBQWtEO0lBQ2xELHdEQUF5QixHQUF6QixVQUEwQixJQUFJO1FBQzVCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDcEIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNULGtCQUFrQjtZQUNsQixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDdkUsQ0FBQztJQUNILENBQUM7SUFFRCwwQ0FBVyxHQUFYLFVBQVksT0FBTztRQUNqQixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUNwQixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxnQkFBZ0IsR0FBRyxtQkFBbUIsQ0FBQztRQUMvRCxDQUFDO1FBQ0QsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsZUFBZSxHQUFHLGlCQUFpQixDQUFDO0lBQzVELENBQUM7SUFFRCx5Q0FBVSxHQUFWLFVBQVcsT0FBZ0I7UUFDekIsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDcEIsT0FBTyxDQUFDLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7WUFDN0IsTUFBTSxDQUFDO1FBQ1QsQ0FBQztRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQzthQUMvQixTQUFTLENBQ1IsY0FBUSxDQUFDLEVBQ1Q7WUFDRSxjQUFLLENBQUMsK0NBQStDLENBQUMsQ0FBQztRQUN6RCxDQUFDLENBQ0YsQ0FBQztJQUNOLENBQUM7SUFFRCxxQ0FBTSxHQUFOLFVBQU8sT0FBZ0I7UUFBdkIsaUJBZUM7UUFkQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN0QixJQUFJLGNBQWMsR0FBRyxjQUFNLE9BQUEsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQXBCLENBQW9CLENBQUM7UUFDaEQsSUFBSSxZQUFZLEdBQUc7WUFDakIsY0FBSyxDQUFDLDBEQUEwRCxDQUFDLENBQUM7WUFDbEUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdkIsQ0FBQyxDQUFDO1FBRUYsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDcEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUM7aUJBQ2xDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDN0MsQ0FBQztRQUFDLElBQUksQ0FBQyxDQUFDO1lBQ04sSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO2lCQUM5QixTQUFTLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQzdDLENBQUM7SUFDSCxDQUFDO0lBQ0gsMkJBQUM7QUFBRCxDQUFDLEFBeEVELElBd0VDO0FBdkVVO0lBQVIsWUFBSyxFQUFFOzt5REFBc0I7QUFDckI7SUFBUixZQUFLLEVBQUU7O2lEQUFLO0FBQ0g7SUFBVCxhQUFNLEVBQUU7O3FEQUE4QjtBQUM3QjtJQUFULGFBQU0sRUFBRTs7b0RBQTZCO0FBSjNCLG9CQUFvQjtJQVBoQyxnQkFBUyxDQUFDO1FBQ1QsUUFBUSxFQUFFLGlCQUFpQjtRQUMzQixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7UUFDbkIsV0FBVyxFQUFFLCtCQUErQjtRQUM1QyxTQUFTLEVBQUUsQ0FBQyw4QkFBOEIsQ0FBQztRQUMzQyxlQUFlLEVBQUUsOEJBQXVCLENBQUMsTUFBTTtLQUNoRCxDQUFDO3FDQVMyQix1QkFBYztHQVI5QixvQkFBb0IsQ0F3RWhDO0FBeEVZLG9EQUFvQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIEV2ZW50RW1pdHRlciwgSW5wdXQsIE91dHB1dCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tIFwidXRpbHMvdXRpbHNcIjtcblxuaW1wb3J0IHsgR3JvY2VyeSwgR3JvY2VyeVNlcnZpY2UgfSBmcm9tIFwiLi4vc2hhcmVkXCI7XG5pbXBvcnQgeyBhbGVydCB9IGZyb20gXCIuLi8uLi9zaGFyZWRcIjtcblxuZGVjbGFyZSB2YXIgVUlDb2xvcjogYW55O1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6IFwiZ3ItZ3JvY2VyeS1saXN0XCIsXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gIHRlbXBsYXRlVXJsOiBcIi4vZ3JvY2VyeS1saXN0LmNvbXBvbmVudC5odG1sXCIsXG4gIHN0eWxlVXJsczogW1wiLi9ncm9jZXJ5LWxpc3QuY29tcG9uZW50LmNzc1wiXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2hcbn0pXG5leHBvcnQgY2xhc3MgR3JvY2VyeUxpc3RDb21wb25lbnQge1xuICBASW5wdXQoKSBzaG93RGVsZXRlZDogYm9vbGVhbjtcbiAgQElucHV0KCkgcm93O1xuICBAT3V0cHV0KCkgbG9hZGluZyA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgQE91dHB1dCgpIGxvYWRlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBsaXN0TG9hZGVkID0gZmFsc2U7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBzdG9yZTogR3JvY2VyeVNlcnZpY2UpIHsgfVxuXG4gIGxvYWQoKSB7XG4gICAgdGhpcy5sb2FkaW5nLm5leHQoXCJcIik7XG4gICAgdGhpcy5zdG9yZS5sb2FkKClcbiAgICAgIC5zdWJzY3JpYmUoXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICB0aGlzLmxvYWRlZC5uZXh0KFwiXCIpO1xuICAgICAgICAgIHRoaXMubGlzdExvYWRlZCA9IHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICBhbGVydChcIkFuIGVycm9yIG9jY3VycmVkIGxvYWRpbmcgeW91ciBncm9jZXJ5IGxpc3QuXCIpO1xuICAgICAgICB9XG4gICAgICApO1xuICB9XG5cbiAgLy8gVGhlIGZvbGxvd2luZyB0cmljayBtYWtlcyB0aGUgYmFja2dyb3VuZCBjb2xvciBvZiBlYWNoIGNlbGxcbiAgLy8gaW4gdGhlIFVJVGFibGVWaWV3IHRyYW5zcGFyZW50IGFzIGl04oCZcyBjcmVhdGVkLlxuICBtYWtlQmFja2dyb3VuZFRyYW5zcGFyZW50KGFyZ3MpIHtcbiAgICBsZXQgY2VsbCA9IGFyZ3MuaW9zO1xuICAgIGlmIChjZWxsKSB7XG4gICAgICAvLyBzdXBwb3J0IFhDb2RlIDhcbiAgICAgIGNlbGwuYmFja2dyb3VuZENvbG9yID0gdXRpbHMuaW9zLmdldHRlcihVSUNvbG9yLCBVSUNvbG9yLmNsZWFyQ29sb3IpO1xuICAgIH1cbiAgfVxuXG4gIGltYWdlU291cmNlKGdyb2NlcnkpIHtcbiAgICBpZiAoZ3JvY2VyeS5kZWxldGVkKSB7XG4gICAgICByZXR1cm4gZ3JvY2VyeS5kb25lID8gXCJyZXM6Ly9zZWxlY3RlZFwiIDogXCJyZXM6Ly9ub25zZWxlY3RlZFwiO1xuICAgIH1cbiAgICByZXR1cm4gZ3JvY2VyeS5kb25lID8gXCJyZXM6Ly9jaGVja2VkXCIgOiBcInJlczovL3VuY2hlY2tlZFwiO1xuICB9XG5cbiAgdG9nZ2xlRG9uZShncm9jZXJ5OiBHcm9jZXJ5KSB7XG4gICAgaWYgKGdyb2NlcnkuZGVsZXRlZCkge1xuICAgICAgZ3JvY2VyeS5kb25lID0gIWdyb2NlcnkuZG9uZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLnN0b3JlLnRvZ2dsZURvbmVGbGFnKGdyb2NlcnkpXG4gICAgICAuc3Vic2NyaWJlKFxuICAgICAgICAoKSA9PiB7IH0sXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICBhbGVydChcIkFuIGVycm9yIG9jY3VycmVkIG1hbmFnaW5nIHlvdXIgZ3JvY2VyeSBsaXN0LlwiKTtcbiAgICAgICAgfVxuICAgICAgKTtcbiAgfVxuXG4gIGRlbGV0ZShncm9jZXJ5OiBHcm9jZXJ5KSB7XG4gICAgdGhpcy5sb2FkaW5nLm5leHQoXCJcIik7XG4gICAgbGV0IHN1Y2Nlc3NIYW5kbGVyID0gKCkgPT4gdGhpcy5sb2FkZWQubmV4dChcIlwiKTtcbiAgICBsZXQgZXJyb3JIYW5kbGVyID0gKCkgPT4ge1xuICAgICAgYWxlcnQoXCJBbiBlcnJvciBvY2N1cnJlZCB3aGlsZSBkZWxldGluZyBhbiBpdGVtIGZyb20geW91ciBsaXN0LlwiKTtcbiAgICAgIHRoaXMubG9hZGVkLm5leHQoXCJcIik7XG4gICAgfTtcblxuICAgIGlmIChncm9jZXJ5LmRlbGV0ZWQpIHtcbiAgICAgIHRoaXMuc3RvcmUucGVybWFuZW50bHlEZWxldGUoZ3JvY2VyeSlcbiAgICAgICAgLnN1YnNjcmliZShzdWNjZXNzSGFuZGxlciwgZXJyb3JIYW5kbGVyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zdG9yZS5zZXREZWxldGVGbGFnKGdyb2NlcnkpXG4gICAgICAgIC5zdWJzY3JpYmUoc3VjY2Vzc0hhbmRsZXIsIGVycm9ySGFuZGxlcik7XG4gICAgfVxuICB9XG59XG5cbiJdfQ==