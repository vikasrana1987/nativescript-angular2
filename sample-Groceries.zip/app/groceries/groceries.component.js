"use strict";
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var dialogs_1 = require("ui/dialogs");
var page_1 = require("ui/page");
var SocialShare = require("nativescript-social-share");
var shared_1 = require("./shared");
var shared_2 = require("../shared");
var GroceriesComponent = (function () {
    function GroceriesComponent(router, store, loginService, page) {
        this.router = router;
        this.store = store;
        this.loginService = loginService;
        this.page = page;
        this.grocery = "";
        this.isShowingRecent = false;
        this.isLoading = false;
    }
    GroceriesComponent.prototype.ngOnInit = function () {
        this.isAndroid = !!this.page.android;
        this.page.actionBarHidden = true;
        this.page.className = "list-page";
    };
    // Prevent the first textfield from receiving focus on Android
    // See http://stackoverflow.com/questions/5056734/android-force-edittext-to-remove-focus
    GroceriesComponent.prototype.handleAndroidFocus = function (textField, container) {
        if (container.android) {
            container.android.setFocusableInTouchMode(true);
            container.android.setFocusable(true);
            textField.android.clearFocus();
        }
    };
    GroceriesComponent.prototype.showActivityIndicator = function () {
        this.isLoading = true;
    };
    GroceriesComponent.prototype.hideActivityIndicator = function () {
        this.isLoading = false;
    };
    GroceriesComponent.prototype.add = function (target) {
        var _this = this;
        // If showing recent groceries the add button should do nothing.
        if (this.isShowingRecent) {
            return;
        }
        var textField = this.groceryTextField.nativeElement;
        if (this.grocery.trim() === "") {
            // If the user clicked the add button, and the textfield is empty,
            // focus the text field and return.
            if (target === "button") {
                textField.focus();
            }
            else {
                // If the user clicked return with an empty text field show an error.
                shared_2.alert("Enter a grocery item");
            }
            return;
        }
        // Dismiss the keyboard
        // TODO: Is it better UX to dismiss the keyboard, or leave it up so the
        // user can continue to add more groceries?
        textField.dismissSoftInput();
        this.showActivityIndicator();
        this.store.add(this.grocery)
            .subscribe(function () {
            _this.grocery = "";
            _this.hideActivityIndicator();
        }, function () {
            shared_2.alert("An error occurred while adding an item to your list.");
            _this.hideActivityIndicator();
        });
    };
    GroceriesComponent.prototype.toggleRecent = function () {
        var _this = this;
        if (!this.isShowingRecent) {
            this.isShowingRecent = true;
            return;
        }
        this.showActivityIndicator();
        this.store.restore()
            .subscribe(function () {
            _this.isShowingRecent = false;
            _this.hideActivityIndicator();
        }, function () {
            shared_2.alert("An error occurred while adding groceries to your list.");
            _this.hideActivityIndicator();
        });
    };
    GroceriesComponent.prototype.showMenu = function () {
        var _this = this;
        dialogs_1.action({
            message: "What would you like to do?",
            actions: ["Share", "Log Off"],
            cancelButtonText: "Cancel"
        }).then(function (result) {
            if (result === "Share") {
                _this.share();
            }
            else if (result === "Log Off") {
                _this.logoff();
            }
        });
    };
    GroceriesComponent.prototype.share = function () {
        var items = this.store.items.value;
        var list = [];
        for (var i = 0, size = items.length; i < size; i++) {
            list.push(items[i].name);
        }
        SocialShare.shareText(list.join(", ").trim());
    };
    GroceriesComponent.prototype.logoff = function () {
        this.loginService.logoff();
        this.router.navigate(["/login"]);
    };
    return GroceriesComponent;
}());
__decorate([
    core_1.ViewChild("groceryTextField"),
    __metadata("design:type", core_1.ElementRef)
], GroceriesComponent.prototype, "groceryTextField", void 0);
GroceriesComponent = __decorate([
    core_1.Component({
        selector: "gr-groceries",
        moduleId: module.id,
        templateUrl: "./groceries.component.html",
        styleUrls: ["./groceries-common.css", "./groceries.component.css"],
        providers: [shared_1.GroceryService]
    }),
    __metadata("design:paramtypes", [router_1.Router,
        shared_1.GroceryService,
        shared_2.LoginService,
        page_1.Page])
], GroceriesComponent);
exports.GroceriesComponent = GroceriesComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JvY2VyaWVzLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImdyb2Nlcmllcy5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUF5RTtBQUN6RSwwQ0FBeUM7QUFDekMsc0NBQW9DO0FBRXBDLGdDQUErQjtBQUUvQix1REFBeUQ7QUFHekQsbUNBQTBDO0FBQzFDLG9DQUFnRDtBQVNoRCxJQUFhLGtCQUFrQjtJQVE3Qiw0QkFBb0IsTUFBYyxFQUN4QixLQUFxQixFQUNyQixZQUEwQixFQUMxQixJQUFVO1FBSEEsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUN4QixVQUFLLEdBQUwsS0FBSyxDQUFnQjtRQUNyQixpQkFBWSxHQUFaLFlBQVksQ0FBYztRQUMxQixTQUFJLEdBQUosSUFBSSxDQUFNO1FBVnBCLFlBQU8sR0FBVyxFQUFFLENBQUM7UUFFckIsb0JBQWUsR0FBRyxLQUFLLENBQUM7UUFDeEIsY0FBUyxHQUFHLEtBQUssQ0FBQztJQU9LLENBQUM7SUFFeEIscUNBQVEsR0FBUjtRQUNFLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztRQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUM7SUFDcEMsQ0FBQztJQUVELDhEQUE4RDtJQUM5RCx3RkFBd0Y7SUFDeEYsK0NBQWtCLEdBQWxCLFVBQW1CLFNBQVMsRUFBRSxTQUFTO1FBQ3JDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQ3RCLFNBQVMsQ0FBQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEQsU0FBUyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNqQyxDQUFDO0lBQ0gsQ0FBQztJQUVELGtEQUFxQixHQUFyQjtRQUNFLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO0lBQ3hCLENBQUM7SUFDRCxrREFBcUIsR0FBckI7UUFDRSxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUN6QixDQUFDO0lBRUQsZ0NBQUcsR0FBSCxVQUFJLE1BQWM7UUFBbEIsaUJBcUNDO1FBcENDLGdFQUFnRTtRQUNoRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztZQUN6QixNQUFNLENBQUM7UUFDVCxDQUFDO1FBRUQsSUFBSSxTQUFTLEdBQWMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQztRQUUvRCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0Isa0VBQWtFO1lBQ2xFLG1DQUFtQztZQUNuQyxFQUFFLENBQUMsQ0FBQyxNQUFNLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFDeEIsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ3BCLENBQUM7WUFBQyxJQUFJLENBQUMsQ0FBQztnQkFDTixxRUFBcUU7Z0JBQ3JFLGNBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ2hDLENBQUM7WUFDRCxNQUFNLENBQUM7UUFDVCxDQUFDO1FBRUQsdUJBQXVCO1FBQ3ZCLHVFQUF1RTtRQUN2RSwyQ0FBMkM7UUFDM0MsU0FBUyxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFFN0IsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQzthQUN6QixTQUFTLENBQ1I7WUFDRSxLQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNsQixLQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUMvQixDQUFDLEVBQ0Q7WUFDRSxjQUFLLENBQUMsc0RBQXNELENBQUMsQ0FBQztZQUM5RCxLQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUMvQixDQUFDLENBQ0YsQ0FBQztJQUNOLENBQUM7SUFFRCx5Q0FBWSxHQUFaO1FBQUEsaUJBa0JDO1FBakJDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7WUFDMUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7WUFDNUIsTUFBTSxDQUFDO1FBQ1QsQ0FBQztRQUVELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFO2FBQ2pCLFNBQVMsQ0FDUjtZQUNFLEtBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1lBQzdCLEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQy9CLENBQUMsRUFDRDtZQUNFLGNBQUssQ0FBQyx3REFBd0QsQ0FBQyxDQUFDO1lBQ2hFLEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQy9CLENBQUMsQ0FDRixDQUFDO0lBQ04sQ0FBQztJQUVELHFDQUFRLEdBQVI7UUFBQSxpQkFZQztRQVhDLGdCQUFNLENBQUM7WUFDTCxPQUFPLEVBQUUsNEJBQTRCO1lBQ3JDLE9BQU8sRUFBRSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7WUFDN0IsZ0JBQWdCLEVBQUUsUUFBUTtTQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsTUFBTTtZQUNiLEVBQUUsQ0FBQyxDQUFDLE1BQU0sS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUN2QixLQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDZixDQUFDO1lBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUNoQyxLQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDaEIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGtDQUFLLEdBQUw7UUFDRSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDbkMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2QsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxJQUFJLEVBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNwRCxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzQixDQUFDO1FBQ0QsV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELG1DQUFNLEdBQU47UUFDRSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBQ0gseUJBQUM7QUFBRCxDQUFDLEFBMUhELElBMEhDO0FBcEhnQztJQUE5QixnQkFBUyxDQUFDLGtCQUFrQixDQUFDOzhCQUFtQixpQkFBVTs0REFBQztBQU5qRCxrQkFBa0I7SUFQOUIsZ0JBQVMsQ0FBQztRQUNULFFBQVEsRUFBRSxjQUFjO1FBQ3hCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtRQUNuQixXQUFXLEVBQUUsNEJBQTRCO1FBQ3pDLFNBQVMsRUFBRSxDQUFDLHdCQUF3QixFQUFFLDJCQUEyQixDQUFDO1FBQ2xFLFNBQVMsRUFBRSxDQUFDLHVCQUFjLENBQUM7S0FDNUIsQ0FBQztxQ0FTNEIsZUFBTTtRQUNqQix1QkFBYztRQUNQLHFCQUFZO1FBQ3BCLFdBQUk7R0FYVCxrQkFBa0IsQ0EwSDlCO0FBMUhZLGdEQUFrQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRWxlbWVudFJlZiwgT25Jbml0LCBWaWV3Q2hpbGQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgYWN0aW9uIH0gZnJvbSBcInVpL2RpYWxvZ3NcIjtcbmltcG9ydCB7IENvbG9yIH0gZnJvbSBcImNvbG9yXCI7XG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcbmltcG9ydCB7IFRleHRGaWVsZCB9IGZyb20gXCJ1aS90ZXh0LWZpZWxkXCI7XG5pbXBvcnQgKiBhcyBTb2NpYWxTaGFyZSBmcm9tIFwibmF0aXZlc2NyaXB0LXNvY2lhbC1zaGFyZVwiO1xuXG5pbXBvcnQgeyBHcm9jZXJ5TGlzdENvbXBvbmVudCB9IGZyb20gXCIuL2dyb2NlcnktbGlzdC9ncm9jZXJ5LWxpc3QuY29tcG9uZW50XCI7XG5pbXBvcnQgeyBHcm9jZXJ5U2VydmljZSB9IGZyb20gXCIuL3NoYXJlZFwiO1xuaW1wb3J0IHsgTG9naW5TZXJ2aWNlLCBhbGVydCB9IGZyb20gXCIuLi9zaGFyZWRcIjtcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiBcImdyLWdyb2Nlcmllc1wiLFxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICB0ZW1wbGF0ZVVybDogXCIuL2dyb2Nlcmllcy5jb21wb25lbnQuaHRtbFwiLFxuICBzdHlsZVVybHM6IFtcIi4vZ3JvY2VyaWVzLWNvbW1vbi5jc3NcIiwgXCIuL2dyb2Nlcmllcy5jb21wb25lbnQuY3NzXCJdLFxuICBwcm92aWRlcnM6IFtHcm9jZXJ5U2VydmljZV1cbn0pXG5leHBvcnQgY2xhc3MgR3JvY2VyaWVzQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgZ3JvY2VyeTogc3RyaW5nID0gXCJcIjtcbiAgaXNBbmRyb2lkO1xuICBpc1Nob3dpbmdSZWNlbnQgPSBmYWxzZTtcbiAgaXNMb2FkaW5nID0gZmFsc2U7XG5cbiAgQFZpZXdDaGlsZChcImdyb2NlcnlUZXh0RmllbGRcIikgZ3JvY2VyeVRleHRGaWVsZDogRWxlbWVudFJlZjtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuICAgIHByaXZhdGUgc3RvcmU6IEdyb2NlcnlTZXJ2aWNlLFxuICAgIHByaXZhdGUgbG9naW5TZXJ2aWNlOiBMb2dpblNlcnZpY2UsXG4gICAgcHJpdmF0ZSBwYWdlOiBQYWdlKSB7fVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMuaXNBbmRyb2lkID0gISF0aGlzLnBhZ2UuYW5kcm9pZDtcbiAgICB0aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcbiAgICB0aGlzLnBhZ2UuY2xhc3NOYW1lID0gXCJsaXN0LXBhZ2VcIjtcbiAgfVxuXG4gIC8vIFByZXZlbnQgdGhlIGZpcnN0IHRleHRmaWVsZCBmcm9tIHJlY2VpdmluZyBmb2N1cyBvbiBBbmRyb2lkXG4gIC8vIFNlZSBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzUwNTY3MzQvYW5kcm9pZC1mb3JjZS1lZGl0dGV4dC10by1yZW1vdmUtZm9jdXNcbiAgaGFuZGxlQW5kcm9pZEZvY3VzKHRleHRGaWVsZCwgY29udGFpbmVyKSB7XG4gICAgaWYgKGNvbnRhaW5lci5hbmRyb2lkKSB7XG4gICAgICBjb250YWluZXIuYW5kcm9pZC5zZXRGb2N1c2FibGVJblRvdWNoTW9kZSh0cnVlKTtcbiAgICAgIGNvbnRhaW5lci5hbmRyb2lkLnNldEZvY3VzYWJsZSh0cnVlKTtcbiAgICAgIHRleHRGaWVsZC5hbmRyb2lkLmNsZWFyRm9jdXMoKTtcbiAgICB9XG4gIH1cblxuICBzaG93QWN0aXZpdHlJbmRpY2F0b3IoKSB7XG4gICAgdGhpcy5pc0xvYWRpbmcgPSB0cnVlO1xuICB9XG4gIGhpZGVBY3Rpdml0eUluZGljYXRvcigpIHtcbiAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlO1xuICB9XG5cbiAgYWRkKHRhcmdldDogc3RyaW5nKSB7XG4gICAgLy8gSWYgc2hvd2luZyByZWNlbnQgZ3JvY2VyaWVzIHRoZSBhZGQgYnV0dG9uIHNob3VsZCBkbyBub3RoaW5nLlxuICAgIGlmICh0aGlzLmlzU2hvd2luZ1JlY2VudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGxldCB0ZXh0RmllbGQgPSA8VGV4dEZpZWxkPnRoaXMuZ3JvY2VyeVRleHRGaWVsZC5uYXRpdmVFbGVtZW50O1xuXG4gICAgaWYgKHRoaXMuZ3JvY2VyeS50cmltKCkgPT09IFwiXCIpIHtcbiAgICAgIC8vIElmIHRoZSB1c2VyIGNsaWNrZWQgdGhlIGFkZCBidXR0b24sIGFuZCB0aGUgdGV4dGZpZWxkIGlzIGVtcHR5LFxuICAgICAgLy8gZm9jdXMgdGhlIHRleHQgZmllbGQgYW5kIHJldHVybi5cbiAgICAgIGlmICh0YXJnZXQgPT09IFwiYnV0dG9uXCIpIHtcbiAgICAgICAgdGV4dEZpZWxkLmZvY3VzKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBJZiB0aGUgdXNlciBjbGlja2VkIHJldHVybiB3aXRoIGFuIGVtcHR5IHRleHQgZmllbGQgc2hvdyBhbiBlcnJvci5cbiAgICAgICAgYWxlcnQoXCJFbnRlciBhIGdyb2NlcnkgaXRlbVwiKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBEaXNtaXNzIHRoZSBrZXlib2FyZFxuICAgIC8vIFRPRE86IElzIGl0IGJldHRlciBVWCB0byBkaXNtaXNzIHRoZSBrZXlib2FyZCwgb3IgbGVhdmUgaXQgdXAgc28gdGhlXG4gICAgLy8gdXNlciBjYW4gY29udGludWUgdG8gYWRkIG1vcmUgZ3JvY2VyaWVzP1xuICAgIHRleHRGaWVsZC5kaXNtaXNzU29mdElucHV0KCk7XG5cbiAgICB0aGlzLnNob3dBY3Rpdml0eUluZGljYXRvcigpO1xuICAgIHRoaXMuc3RvcmUuYWRkKHRoaXMuZ3JvY2VyeSlcbiAgICAgIC5zdWJzY3JpYmUoXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICB0aGlzLmdyb2NlcnkgPSBcIlwiO1xuICAgICAgICAgIHRoaXMuaGlkZUFjdGl2aXR5SW5kaWNhdG9yKCk7XG4gICAgICAgIH0sXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICBhbGVydChcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIGFkZGluZyBhbiBpdGVtIHRvIHlvdXIgbGlzdC5cIik7XG4gICAgICAgICAgdGhpcy5oaWRlQWN0aXZpdHlJbmRpY2F0b3IoKTtcbiAgICAgICAgfVxuICAgICAgKTtcbiAgfVxuXG4gIHRvZ2dsZVJlY2VudCgpIHtcbiAgICBpZiAoIXRoaXMuaXNTaG93aW5nUmVjZW50KSB7XG4gICAgICB0aGlzLmlzU2hvd2luZ1JlY2VudCA9IHRydWU7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5zaG93QWN0aXZpdHlJbmRpY2F0b3IoKTtcbiAgICB0aGlzLnN0b3JlLnJlc3RvcmUoKVxuICAgICAgLnN1YnNjcmliZShcbiAgICAgICAgKCkgPT4ge1xuICAgICAgICAgIHRoaXMuaXNTaG93aW5nUmVjZW50ID0gZmFsc2U7XG4gICAgICAgICAgdGhpcy5oaWRlQWN0aXZpdHlJbmRpY2F0b3IoKTtcbiAgICAgICAgfSxcbiAgICAgICAgKCkgPT4ge1xuICAgICAgICAgIGFsZXJ0KFwiQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgYWRkaW5nIGdyb2NlcmllcyB0byB5b3VyIGxpc3QuXCIpO1xuICAgICAgICAgIHRoaXMuaGlkZUFjdGl2aXR5SW5kaWNhdG9yKCk7XG4gICAgICAgIH1cbiAgICAgICk7XG4gIH1cblxuICBzaG93TWVudSgpIHtcbiAgICBhY3Rpb24oe1xuICAgICAgbWVzc2FnZTogXCJXaGF0IHdvdWxkIHlvdSBsaWtlIHRvIGRvP1wiLFxuICAgICAgYWN0aW9uczogW1wiU2hhcmVcIiwgXCJMb2cgT2ZmXCJdLFxuICAgICAgY2FuY2VsQnV0dG9uVGV4dDogXCJDYW5jZWxcIlxuICAgIH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgaWYgKHJlc3VsdCA9PT0gXCJTaGFyZVwiKSB7XG4gICAgICAgIHRoaXMuc2hhcmUoKTtcbiAgICAgIH0gZWxzZSBpZiAocmVzdWx0ID09PSBcIkxvZyBPZmZcIikge1xuICAgICAgICB0aGlzLmxvZ29mZigpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgc2hhcmUoKSB7XG4gICAgbGV0IGl0ZW1zID0gdGhpcy5zdG9yZS5pdGVtcy52YWx1ZTtcbiAgICBsZXQgbGlzdCA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwLCBzaXplID0gaXRlbXMubGVuZ3RoOyBpIDwgc2l6ZSA7IGkrKykge1xuICAgICAgbGlzdC5wdXNoKGl0ZW1zW2ldLm5hbWUpO1xuICAgIH1cbiAgICBTb2NpYWxTaGFyZS5zaGFyZVRleHQobGlzdC5qb2luKFwiLCBcIikudHJpbSgpKTtcbiAgfVxuXG4gIGxvZ29mZigpIHtcbiAgICB0aGlzLmxvZ2luU2VydmljZS5sb2dvZmYoKTtcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvbG9naW5cIl0pO1xuICB9XG59XG4iXX0=