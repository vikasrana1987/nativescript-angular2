"use strict";
var Grocery = (function () {
    function Grocery(id, name, done, deleted) {
        this.id = id;
        this.name = name;
        this.done = done;
        this.deleted = deleted;
    }
    return Grocery;
}());
exports.Grocery = Grocery;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JvY2VyeS5tb2RlbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImdyb2NlcnkubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0lBQ0UsaUJBQ1MsRUFBVSxFQUNWLElBQVksRUFDWixJQUFhLEVBQ2IsT0FBZ0I7UUFIaEIsT0FBRSxHQUFGLEVBQUUsQ0FBUTtRQUNWLFNBQUksR0FBSixJQUFJLENBQVE7UUFDWixTQUFJLEdBQUosSUFBSSxDQUFTO1FBQ2IsWUFBTyxHQUFQLE9BQU8sQ0FBUztJQUN0QixDQUFDO0lBQ04sY0FBQztBQUFELENBQUMsQUFQRCxJQU9DO0FBUFksMEJBQU8iLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgR3JvY2VyeSB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHB1YmxpYyBpZDogc3RyaW5nLFxuICAgIHB1YmxpYyBuYW1lOiBzdHJpbmcsXG4gICAgcHVibGljIGRvbmU6IGJvb2xlYW4sXG4gICAgcHVibGljIGRlbGV0ZWQ6IGJvb2xlYW5cbiAgKSB7fVxufSJdfQ==