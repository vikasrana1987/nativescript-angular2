"use strict";
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Rx_1 = require("rxjs/Rx");
require("rxjs/add/operator/map");
var shared_1 = require("../../shared");
var grocery_model_1 = require("./grocery.model");
var GroceryService = (function () {
    function GroceryService(http, zone) {
        this.http = http;
        this.zone = zone;
        this.items = new Rx_1.BehaviorSubject([]);
        this.allItems = [];
    }
    GroceryService.prototype.load = function () {
        var _this = this;
        var headers = this.getHeaders();
        headers.append("X-Everlive-Sort", JSON.stringify({ ModifiedAt: -1 }));
        return this.http.get(shared_1.BackendService.apiUrl + "Groceries", {
            headers: headers
        })
            .map(function (res) { return res.json(); })
            .map(function (data) {
            data.Result.forEach(function (grocery) {
                _this.allItems.push(new grocery_model_1.Grocery(grocery.Id, grocery.Name, grocery.Done || false, grocery.Deleted || false));
                _this.publishUpdates();
            });
        })
            .catch(this.handleErrors);
    };
    GroceryService.prototype.add = function (name) {
        var _this = this;
        return this.http.post(shared_1.BackendService.apiUrl + "Groceries", JSON.stringify({ Name: name }), { headers: this.getHeaders() })
            .map(function (res) { return res.json(); })
            .map(function (data) {
            _this.allItems.unshift(new grocery_model_1.Grocery(data.Result.Id, name, false, false));
            _this.publishUpdates();
        })
            .catch(this.handleErrors);
    };
    GroceryService.prototype.setDeleteFlag = function (item) {
        var _this = this;
        return this.put(item.id, { Deleted: true, Done: false })
            .map(function (res) { return res.json(); })
            .map(function (data) {
            item.deleted = true;
            item.done = false;
            _this.publishUpdates();
        });
    };
    GroceryService.prototype.toggleDoneFlag = function (item) {
        item.done = !item.done;
        this.publishUpdates();
        return this.put(item.id, { Done: item.done })
            .map(function (res) { return res.json(); });
    };
    GroceryService.prototype.restore = function () {
        var _this = this;
        var indeces = [];
        this.allItems.forEach(function (grocery) {
            if (grocery.deleted && grocery.done) {
                indeces.push(grocery.id);
            }
        });
        var headers = this.getHeaders();
        headers.append("X-Everlive-Filter", JSON.stringify({
            "Id": {
                "$in": indeces
            }
        }));
        return this.http.put(shared_1.BackendService.apiUrl + "Groceries", JSON.stringify({
            Deleted: false,
            Done: false
        }), { headers: headers })
            .map(function (res) { return res.json(); })
            .map(function (data) {
            _this.allItems.forEach(function (grocery) {
                if (grocery.deleted && grocery.done) {
                    grocery.deleted = false;
                    grocery.done = false;
                }
            });
            _this.publishUpdates();
        })
            .catch(this.handleErrors);
    };
    GroceryService.prototype.permanentlyDelete = function (item) {
        var _this = this;
        return this.http
            .delete(shared_1.BackendService.apiUrl + "Groceries/" + item.id, { headers: this.getHeaders() })
            .map(function (res) { return res.json(); })
            .map(function (data) {
            var index = _this.allItems.indexOf(item);
            _this.allItems.splice(index, 1);
            _this.publishUpdates();
        })
            .catch(this.handleErrors);
    };
    GroceryService.prototype.put = function (id, data) {
        return this.http.put(shared_1.BackendService.apiUrl + "Groceries/" + id, JSON.stringify(data), { headers: this.getHeaders() })
            .catch(this.handleErrors);
    };
    GroceryService.prototype.publishUpdates = function () {
        var _this = this;
        // Make sure all updates are published inside NgZone so that change detection is triggered if needed
        this.zone.run(function () {
            // must emit a *new* value (immutability!)
            _this.items.next(_this.allItems.slice());
        });
    };
    GroceryService.prototype.getHeaders = function () {
        var headers = new http_1.Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Authorization", "Bearer " + shared_1.BackendService.token);
        return headers;
    };
    GroceryService.prototype.handleErrors = function (error) {
        console.log(error);
        return Rx_1.Observable.throw(error);
    };
    return GroceryService;
}());
GroceryService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http, core_1.NgZone])
], GroceryService);
exports.GroceryService = GroceryService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JvY2VyeS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZ3JvY2VyeS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzQ0FBbUQ7QUFDbkQsc0NBQXlFO0FBQ3pFLDhCQUFzRDtBQUN0RCxpQ0FBK0I7QUFFL0IsdUNBQThDO0FBQzlDLGlEQUEwQztBQUcxQyxJQUFhLGNBQWM7SUFLekIsd0JBQW9CLElBQVUsRUFBVSxJQUFZO1FBQWhDLFNBQUksR0FBSixJQUFJLENBQU07UUFBVSxTQUFJLEdBQUosSUFBSSxDQUFRO1FBSnBELFVBQUssR0FBb0MsSUFBSSxvQkFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXpELGFBQVEsR0FBbUIsRUFBRSxDQUFDO0lBRWtCLENBQUM7SUFFekQsNkJBQUksR0FBSjtRQUFBLGlCQXNCQztRQXJCQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXRFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyx1QkFBYyxDQUFDLE1BQU0sR0FBRyxXQUFXLEVBQUU7WUFDeEQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQzthQUNELEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUM7YUFDdEIsR0FBRyxDQUFDLFVBQUEsSUFBSTtZQUNQLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUMsT0FBTztnQkFDMUIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ2hCLElBQUksdUJBQU8sQ0FDVCxPQUFPLENBQUMsRUFBRSxFQUNWLE9BQU8sQ0FBQyxJQUFJLEVBQ1osT0FBTyxDQUFDLElBQUksSUFBSSxLQUFLLEVBQ3JCLE9BQU8sQ0FBQyxPQUFPLElBQUksS0FBSyxDQUN6QixDQUNGLENBQUM7Z0JBQ0YsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBRUQsNEJBQUcsR0FBSCxVQUFJLElBQVk7UUFBaEIsaUJBWUM7UUFYQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ25CLHVCQUFjLENBQUMsTUFBTSxHQUFHLFdBQVcsRUFDbkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUM5QixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FDL0I7YUFDQSxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDO2FBQ3RCLEdBQUcsQ0FBQyxVQUFBLElBQUk7WUFDUCxLQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLHVCQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUM7YUFDRCxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFFRCxzQ0FBYSxHQUFiLFVBQWMsSUFBYTtRQUEzQixpQkFRQztRQVBDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQzthQUNyRCxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDO2FBQ3RCLEdBQUcsQ0FBQyxVQUFBLElBQUk7WUFDUCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztZQUNwQixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztZQUNsQixLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDeEIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsdUNBQWMsR0FBZCxVQUFlLElBQWE7UUFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQzFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxJQUFJLEVBQUUsRUFBVixDQUFVLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBRUQsZ0NBQU8sR0FBUDtRQUFBLGlCQWtDQztRQWpDQyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBQyxPQUFPO1lBQzVCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3BDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzNCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNoQyxPQUFPLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7WUFDakQsSUFBSSxFQUFFO2dCQUNKLEtBQUssRUFBRSxPQUFPO2FBQ2Y7U0FDRixDQUFDLENBQUMsQ0FBQztRQUVKLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDbEIsdUJBQWMsQ0FBQyxNQUFNLEdBQUcsV0FBVyxFQUNuQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2IsT0FBTyxFQUFFLEtBQUs7WUFDZCxJQUFJLEVBQUUsS0FBSztTQUNaLENBQUMsRUFDRixFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsQ0FDckI7YUFDQSxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDO2FBQ3RCLEdBQUcsQ0FBQyxVQUFBLElBQUk7WUFDUCxLQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFDLE9BQU87Z0JBQzVCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQ3BDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO29CQUN4QixPQUFPLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztnQkFDdkIsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0gsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVELDBDQUFpQixHQUFqQixVQUFrQixJQUFhO1FBQS9CLGlCQWFDO1FBWkMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJO2FBQ2IsTUFBTSxDQUNMLHVCQUFjLENBQUMsTUFBTSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsRUFBRSxFQUM5QyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FDL0I7YUFDQSxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQVYsQ0FBVSxDQUFDO2FBQ3RCLEdBQUcsQ0FBQyxVQUFBLElBQUk7WUFDUCxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN4QyxLQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0IsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVPLDRCQUFHLEdBQVgsVUFBWSxFQUFVLEVBQUUsSUFBWTtRQUNsQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ2xCLHVCQUFjLENBQUMsTUFBTSxHQUFHLFlBQVksR0FBRyxFQUFFLEVBQ3pDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQ3BCLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUMvQjthQUNBLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVPLHVDQUFjLEdBQXRCO1FBQUEsaUJBTUM7UUFMQyxvR0FBb0c7UUFDcEcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDWiwwQ0FBMEM7WUFDMUMsS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUssS0FBSSxDQUFDLFFBQVEsU0FBRSxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLG1DQUFVLEdBQWxCO1FBQ0UsSUFBSSxPQUFPLEdBQUcsSUFBSSxjQUFPLEVBQUUsQ0FBQztRQUM1QixPQUFPLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBQ25ELE9BQU8sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLFNBQVMsR0FBRyx1QkFBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xFLE1BQU0sQ0FBQyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVPLHFDQUFZLEdBQXBCLFVBQXFCLEtBQWU7UUFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNuQixNQUFNLENBQUMsZUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBQ0gscUJBQUM7QUFBRCxDQUFDLEFBN0lELElBNklDO0FBN0lZLGNBQWM7SUFEMUIsaUJBQVUsRUFBRTtxQ0FNZSxXQUFJLEVBQWdCLGFBQU07R0FMekMsY0FBYyxDQTZJMUI7QUE3SVksd0NBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBOZ1pvbmUgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgSHR0cCwgSGVhZGVycywgUmVzcG9uc2UsIFJlc3BvbnNlT3B0aW9ucyB9IGZyb20gXCJAYW5ndWxhci9odHRwXCI7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBCZWhhdmlvclN1YmplY3QgfSBmcm9tIFwicnhqcy9SeFwiO1xuaW1wb3J0IFwicnhqcy9hZGQvb3BlcmF0b3IvbWFwXCI7XG5cbmltcG9ydCB7IEJhY2tlbmRTZXJ2aWNlIH0gZnJvbSBcIi4uLy4uL3NoYXJlZFwiO1xuaW1wb3J0IHsgR3JvY2VyeSB9IGZyb20gXCIuL2dyb2NlcnkubW9kZWxcIjtcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIEdyb2NlcnlTZXJ2aWNlIHtcbiAgaXRlbXM6IEJlaGF2aW9yU3ViamVjdDxBcnJheTxHcm9jZXJ5Pj4gPSBuZXcgQmVoYXZpb3JTdWJqZWN0KFtdKTtcblxuICBwcml2YXRlIGFsbEl0ZW1zOiBBcnJheTxHcm9jZXJ5PiA9IFtdO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cCwgcHJpdmF0ZSB6b25lOiBOZ1pvbmUpIHsgfVxuXG4gIGxvYWQoKSB7XG4gICAgbGV0IGhlYWRlcnMgPSB0aGlzLmdldEhlYWRlcnMoKTtcbiAgICBoZWFkZXJzLmFwcGVuZChcIlgtRXZlcmxpdmUtU29ydFwiLCBKU09OLnN0cmluZ2lmeSh7IE1vZGlmaWVkQXQ6IC0xIH0pKTtcblxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KEJhY2tlbmRTZXJ2aWNlLmFwaVVybCArIFwiR3JvY2VyaWVzXCIsIHtcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICB9KVxuICAgIC5tYXAocmVzID0+IHJlcy5qc29uKCkpXG4gICAgLm1hcChkYXRhID0+IHtcbiAgICAgIGRhdGEuUmVzdWx0LmZvckVhY2goKGdyb2NlcnkpID0+IHtcbiAgICAgICAgdGhpcy5hbGxJdGVtcy5wdXNoKFxuICAgICAgICAgIG5ldyBHcm9jZXJ5KFxuICAgICAgICAgICAgZ3JvY2VyeS5JZCxcbiAgICAgICAgICAgIGdyb2NlcnkuTmFtZSxcbiAgICAgICAgICAgIGdyb2NlcnkuRG9uZSB8fCBmYWxzZSxcbiAgICAgICAgICAgIGdyb2NlcnkuRGVsZXRlZCB8fCBmYWxzZVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5wdWJsaXNoVXBkYXRlcygpO1xuICAgICAgfSk7XG4gICAgfSlcbiAgICAuY2F0Y2godGhpcy5oYW5kbGVFcnJvcnMpO1xuICB9XG5cbiAgYWRkKG5hbWU6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcbiAgICAgIEJhY2tlbmRTZXJ2aWNlLmFwaVVybCArIFwiR3JvY2VyaWVzXCIsXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IE5hbWU6IG5hbWUgfSksXG4gICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0SGVhZGVycygpIH1cbiAgICApXG4gICAgLm1hcChyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAubWFwKGRhdGEgPT4ge1xuICAgICAgdGhpcy5hbGxJdGVtcy51bnNoaWZ0KG5ldyBHcm9jZXJ5KGRhdGEuUmVzdWx0LklkLCBuYW1lLCBmYWxzZSwgZmFsc2UpKTtcbiAgICAgIHRoaXMucHVibGlzaFVwZGF0ZXMoKTtcbiAgICB9KVxuICAgIC5jYXRjaCh0aGlzLmhhbmRsZUVycm9ycyk7XG4gIH1cblxuICBzZXREZWxldGVGbGFnKGl0ZW06IEdyb2NlcnkpIHtcbiAgICByZXR1cm4gdGhpcy5wdXQoaXRlbS5pZCwgeyBEZWxldGVkOiB0cnVlLCBEb25lOiBmYWxzZSB9KVxuICAgICAgLm1hcChyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAgIC5tYXAoZGF0YSA9PiB7XG4gICAgICAgIGl0ZW0uZGVsZXRlZCA9IHRydWU7XG4gICAgICAgIGl0ZW0uZG9uZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnB1Ymxpc2hVcGRhdGVzKCk7XG4gICAgICB9KTtcbiAgfVxuXG4gIHRvZ2dsZURvbmVGbGFnKGl0ZW06IEdyb2NlcnkpIHtcbiAgICBpdGVtLmRvbmUgPSAhaXRlbS5kb25lO1xuICAgIHRoaXMucHVibGlzaFVwZGF0ZXMoKTtcbiAgICByZXR1cm4gdGhpcy5wdXQoaXRlbS5pZCwgeyBEb25lOiBpdGVtLmRvbmUgfSlcbiAgICAgIC5tYXAocmVzID0+IHJlcy5qc29uKCkpO1xuICB9XG5cbiAgcmVzdG9yZSgpIHtcbiAgICBsZXQgaW5kZWNlcyA9IFtdO1xuICAgIHRoaXMuYWxsSXRlbXMuZm9yRWFjaCgoZ3JvY2VyeSkgPT4ge1xuICAgICAgaWYgKGdyb2NlcnkuZGVsZXRlZCAmJiBncm9jZXJ5LmRvbmUpIHtcbiAgICAgICAgaW5kZWNlcy5wdXNoKGdyb2NlcnkuaWQpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgbGV0IGhlYWRlcnMgPSB0aGlzLmdldEhlYWRlcnMoKTtcbiAgICBoZWFkZXJzLmFwcGVuZChcIlgtRXZlcmxpdmUtRmlsdGVyXCIsIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgIFwiSWRcIjoge1xuICAgICAgICBcIiRpblwiOiBpbmRlY2VzXG4gICAgICB9XG4gICAgfSkpO1xuXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQoXG4gICAgICBCYWNrZW5kU2VydmljZS5hcGlVcmwgKyBcIkdyb2Nlcmllc1wiLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBEZWxldGVkOiBmYWxzZSxcbiAgICAgICAgRG9uZTogZmFsc2VcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiBoZWFkZXJzIH1cbiAgICApXG4gICAgLm1hcChyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAubWFwKGRhdGEgPT4ge1xuICAgICAgdGhpcy5hbGxJdGVtcy5mb3JFYWNoKChncm9jZXJ5KSA9PiB7XG4gICAgICAgIGlmIChncm9jZXJ5LmRlbGV0ZWQgJiYgZ3JvY2VyeS5kb25lKSB7XG4gICAgICAgICAgZ3JvY2VyeS5kZWxldGVkID0gZmFsc2U7XG4gICAgICAgICAgZ3JvY2VyeS5kb25lID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgdGhpcy5wdWJsaXNoVXBkYXRlcygpO1xuICAgIH0pXG4gICAgLmNhdGNoKHRoaXMuaGFuZGxlRXJyb3JzKTtcbiAgfVxuXG4gIHBlcm1hbmVudGx5RGVsZXRlKGl0ZW06IEdyb2NlcnkpIHtcbiAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAuZGVsZXRlKFxuICAgICAgICBCYWNrZW5kU2VydmljZS5hcGlVcmwgKyBcIkdyb2Nlcmllcy9cIiArIGl0ZW0uaWQsXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRIZWFkZXJzKCkgfVxuICAgICAgKVxuICAgICAgLm1hcChyZXMgPT4gcmVzLmpzb24oKSlcbiAgICAgIC5tYXAoZGF0YSA9PiB7XG4gICAgICAgIGxldCBpbmRleCA9IHRoaXMuYWxsSXRlbXMuaW5kZXhPZihpdGVtKTtcbiAgICAgICAgdGhpcy5hbGxJdGVtcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICB0aGlzLnB1Ymxpc2hVcGRhdGVzKCk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKHRoaXMuaGFuZGxlRXJyb3JzKTtcbiAgfVxuXG4gIHByaXZhdGUgcHV0KGlkOiBzdHJpbmcsIGRhdGE6IE9iamVjdCkge1xuICAgIHJldHVybiB0aGlzLmh0dHAucHV0KFxuICAgICAgQmFja2VuZFNlcnZpY2UuYXBpVXJsICsgXCJHcm9jZXJpZXMvXCIgKyBpZCxcbiAgICAgIEpTT04uc3RyaW5naWZ5KGRhdGEpLFxuICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldEhlYWRlcnMoKSB9XG4gICAgKVxuICAgIC5jYXRjaCh0aGlzLmhhbmRsZUVycm9ycyk7XG4gIH1cblxuICBwcml2YXRlIHB1Ymxpc2hVcGRhdGVzKCkge1xuICAgIC8vIE1ha2Ugc3VyZSBhbGwgdXBkYXRlcyBhcmUgcHVibGlzaGVkIGluc2lkZSBOZ1pvbmUgc28gdGhhdCBjaGFuZ2UgZGV0ZWN0aW9uIGlzIHRyaWdnZXJlZCBpZiBuZWVkZWRcbiAgICB0aGlzLnpvbmUucnVuKCgpID0+IHtcbiAgICAgIC8vIG11c3QgZW1pdCBhICpuZXcqIHZhbHVlIChpbW11dGFiaWxpdHkhKVxuICAgICAgdGhpcy5pdGVtcy5uZXh0KFsuLi50aGlzLmFsbEl0ZW1zXSk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGdldEhlYWRlcnMoKSB7XG4gICAgbGV0IGhlYWRlcnMgPSBuZXcgSGVhZGVycygpO1xuICAgIGhlYWRlcnMuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICBoZWFkZXJzLmFwcGVuZChcIkF1dGhvcml6YXRpb25cIiwgXCJCZWFyZXIgXCIgKyBCYWNrZW5kU2VydmljZS50b2tlbik7XG4gICAgcmV0dXJuIGhlYWRlcnM7XG4gIH1cblxuICBwcml2YXRlIGhhbmRsZUVycm9ycyhlcnJvcjogUmVzcG9uc2UpIHtcbiAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgcmV0dXJuIE9ic2VydmFibGUudGhyb3coZXJyb3IpO1xuICB9XG59Il19